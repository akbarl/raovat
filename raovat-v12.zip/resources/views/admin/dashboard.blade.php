@extends('layouts.admin')

@section('content')
            <div class="panel panel-default">
                <div class="panel-heading">Trang chính</div>

                <div class="panel-body">
					Nội dung
                </div>
            </div>
@endsection
