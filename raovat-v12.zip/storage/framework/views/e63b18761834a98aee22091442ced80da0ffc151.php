<?php $__env->startSection('content'); ?>
            <div class="panel panel-default">
                <div class="panel-heading">Danh mục</div>

                <div class="panel-body">
					<?php if(isset($m)): ?>
						<div class="alert alert-<?php echo e($stt); ?>">
							<?php echo e($m); ?>

						</div>
					<?php endif; ?>
					<table class="table table-bordered grocery-crud-table table-hover">
						<div style="padding: 0 0 15px 0">
								<a class="btn btn-primary"  href="<?php echo e(url('admin/category/create')); ?>"><i class="fa fa-plus"></i> &nbsp; Thêm danh mục </a>
						</div>
						<thead>
							<tr>
								<th>ID</th>
								<th>Tên</th>
								<th>Sửa</th>
								<th>Xóa</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<tr>
									<td><?php echo e($c->id); ?></td>
									<td><?php echo e($c->name); ?></td>
									<td>
										<a class="btn btn-info" href="<?php echo e(url('admin/category')); ?>/<?php echo e($c->id); ?>/edit"><i class="fa fa-pencil"></i> &nbsp; Sửa</a>
									</td>
									<td>
										<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('admin/category')); ?>/<?php echo e($c['id']); ?>">
											<?php echo e(csrf_field()); ?>

											<?php echo e(method_field('DELETE')); ?>

											<button type="submit" class="btn btn-danger">
												<i class="fa fa-close"></i> &nbsp; Xóa
											</button>
										</form>
									</td>

								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</tbody>
					</table>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>