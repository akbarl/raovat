<?php $__env->startSection('content'); ?>
            <div class="panel panel-default">
                <div class="panel-heading">Thêm danh mục con</div>

                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/admin/subcategory')); ?>">
						<?php echo e(csrf_field()); ?>

						<div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
							<label for="category" class="col-md-4 control-label">Danh mục</label>
							<div class="col-md-6">
								<select class="form-control" name="category">
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
									<?php if(old('category') == $category->id): ?>
										<option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
									<?php else: ?>
										<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
								</select>
							</div>
						</div>
						
						<div class="form-group<?php echo e($errors->has('subcategory') ? ' has-error' : ''); ?>">
							<label for="subcategory" class="col-md-4 control-label">Tên danh mục con</label>
							<div class="col-md-6">
                                <input id="subcategory" type="text" class="form-control" name="subcategory" value="<?php echo e(old('subcategory')); ?>" required autofocus>

                                <?php if($errors->has('subcategory')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('subcategory')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
						</div>
						
						<div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Thêm danh mục con
                                </button>
                            </div>
                        </div>
					</form>
                </div>
            </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>