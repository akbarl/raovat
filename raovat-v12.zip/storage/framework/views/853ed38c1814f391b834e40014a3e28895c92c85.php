<?php $__env->startSection('content'); ?>
            <div class="panel panel-default">
                <div class="panel-heading">Thêm danh dục</div>

                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/admin/category')); ?>">
						<?php echo e(csrf_field()); ?>

						<div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
							<label for="category" class="col-md-4 control-label">Tên danh mục</label>
							<div class="col-md-6">
                                <input id="category" type="text" class="form-control" name="category" value="<?php echo e(old('category')); ?>" required autofocus>

                                <?php if($errors->has('category')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('category')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
						</div>
						
						<div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Thêm danh mục
                                </button>
                            </div>
                        </div>
					</form>
                </div>
            </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>