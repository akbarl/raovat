<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        
            <div class="intro" style="background-image: url(images/bg3.jpg);">
				<div class="container text-center">
					<h1 class="intro-title"> TÌM KIẾM RAO VẶT</h1>
					<p> Chọn nơi ở hiện tại và nội dung </p>
					<form action="search">
						<div class="col-lg-2 col-sm-2">
							  <select name="location" class="form-control">
							  <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<option value="<?php echo e($l->id); ?>"><?php echo e($l->name); ?></option>
							  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
							  </select>
						</div>
						<div class="col-lg-6 col-sm-6"></i>
							<input type="text" name="content" class="form-control" placeholder="Bạn đang tìm gì?" value="">
						</div>
						<div class="col-lg-4 col-sm-4">
							<button class="btn btn-primary btn-search btn-block"><i class="fa fa-search"></i><strong> Tìm kiếm</strong></button>
						</div>
					</form>
				</div>
			</div>
			
			<div class="content">
				<div class="panel panel-default">
					  <div class="panel-heading">Danh mục</div>
					  <div class="panel-body">
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<div class="col-md-3"><a href="category/<?php echo e($c->id); ?>"><?php echo e($c->name); ?></a></div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					  </div>
				</div>
				
				<div class="panel panel-default">
					  <div class="panel-heading">Bài viết mới nhất</div>
					  <div class="panel-body">
							
							<?php $__currentLoopData = App\Thread::all()->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<!-- <a class="list-group-item" href="<?php echo e(url('thread')); ?>/<?php echo e($thread->id); ?>"><?php echo e($thread->title); ?> <span class="badge"><?php echo e(number_format($thread->price)); ?></span></a> -->
							<div class="media">
							  <div class="media-left">
							  
								<a href="/thread/<?php echo e($thread->id); ?>"><img src="/uploads/<?php echo e(App\Image::where('thread_id',$thread->id)->firstOrFail()['name']); ?>" class="media-object" style="width:60px"></a>
							  </div>
							  <div class="media-body">
								<h4 class="media-heading"><a href="/thread/<?php echo e($thread->id); ?>"><?php echo e($thread->title); ?></a></h4>
								<p><?php echo e($thread->description); ?></p>
							  </div>
							</div>
							
							<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					  </div>
				</div>
				
			</div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>