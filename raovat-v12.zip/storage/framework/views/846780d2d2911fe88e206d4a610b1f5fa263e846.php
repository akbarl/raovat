<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading">Thông tin cá nhân</div>
				<?php if($m): ?>
						<div class="alert alert-<?php echo e($stt); ?>">
							<?php echo e($m); ?>

						</div>
				<?php endif; ?>
                <div class="panel-body">
				<?php if(!isset($user['address']) ||
					!isset($user['birth']) ||
					!isset($user['sex']) ||
					!isset($user['phone']) ||
					!isset($user['location'])): ?>
					Vui lòng cập nhật thông tin cá nhân tại <a href="<?php echo e(url('/account/edit')); ?>">đây</a>
				<?php else: ?>
					<div class="row col-md-12">
						<div class="row">
							<div class="col-md-2 col-xs-2 text-primary">Tên</div>
							<div class="col-md-2 col-xs-2"><?php echo e($user['name']); ?></div>
							<div class="col-md-2 col-xs-2 text-primary">Email</div>
							<div class="col-md-2 col-xs-2"><?php echo e($user['email']); ?></div>
						</div>
						<div class="row">
							<div class="col-md-2 col-xs-2 text-primary">Ngày sinh</div>
							<div class="col-md-2 col-xs-2"><?php echo e($user['birth']); ?></div>
							<div class="col-md-2 col-xs-2 text-primary">Địa chỉ</div>
							<div class="col-md-6 col-xs-6"><?php echo e($user['address']); ?></div>
						</div>
						
						<div class="row">
							<div class="col-md-2 col-xs-2 text-primary">Giới tính</div>
							<?php if($user['sex'] == 1): ?>
								<div class="col-md-2 col-xs-2">Nam</div>
							<?php else: ?>
								<div class="col-md-2 col-xs-2">Nữ</div>
							<?php endif; ?>
							<div class="col-md-2 col-xs-2 text-primary">Số điện thoại</div>
							<div class="col-md-2 col-xs-2"><?php echo e($user['phone']); ?></div>
						</div>
						
						<div class="row">
							<div class="col-md-2 col-xs-2 text-primary">Đang sống ở</div>
							<div class="col-md-2 col-xs-2"><?php echo e($location); ?></div>
						</div>
					</div>
				<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>