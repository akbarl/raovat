<?php
	return [
		'paginate' => 2,
	]
?>